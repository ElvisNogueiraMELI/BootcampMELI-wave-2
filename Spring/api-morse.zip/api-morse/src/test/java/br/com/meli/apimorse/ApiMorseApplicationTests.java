package br.com.meli.apimorse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiMorseApplicationTests {

	@Test
	void contextLoads() {
	}

}

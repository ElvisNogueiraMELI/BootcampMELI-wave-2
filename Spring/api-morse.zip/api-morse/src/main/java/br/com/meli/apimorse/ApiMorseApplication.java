package br.com.meli.apimorse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiMorseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiMorseApplication.class, args);
	}

}
